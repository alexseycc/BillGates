Run Mercurial tests with Vagrant:

$ vagrant up
$ vagrant ssh -c ./run-tests.sh
